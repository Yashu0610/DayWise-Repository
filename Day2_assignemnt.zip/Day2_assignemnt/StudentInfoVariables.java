package Java_Day_2_Assignment;

public class StudentInfoVariables {

	public static void main(String[] args) {
		int id = 101;
        String name = "Arun";
        double marks = 89.5;
        char grade = 'A';
        System.out.println("Student ID: " + id);
        System.out.println("Name: " + name);
        System.out.println("Marks: " + marks);
        System.out.println("Grade: " + grade);

	}

}
