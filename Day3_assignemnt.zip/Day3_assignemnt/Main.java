package Oops;

public class Main {
    public static void main(String[] args) {
        BankBranch branch = new BankBranch("B001", "Main Branch");
        Customer c1 = new Customer("C001", "Alice");

        branch.addCustomer(c1);

        SavingsAccount sa = new SavingsAccount("S001", 5000);
        CurrentAccount ca = new CurrentAccount("C001", 2000);

        c1.addAccount(sa);
        c1.addAccount(ca);

        sa.deposit(2000);
        ca.withdraw(2500);
        sa.transfer(ca, 1000);

        sa.showTransactionHistory();
        ca.showTransactionHistory();
    }
}
